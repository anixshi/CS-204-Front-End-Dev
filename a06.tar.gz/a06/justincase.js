        
        /*global $*/
        /*global 'click'*/
        var boardArray = [["1","2","3","4"],
                          ["5","6","7","8"],
                          ["9","10","11","12"],
                          ["13","14","15","16"]];
        var overallClickCount = 0; 
        var clickCount = 0;
        var matchCount = 0; 
        clickCount = 1;
        
        // Stage 0: reveal and conceal images on the game board
        shuffleImages();
        function showImage(id){
            $("#"+id).attr("src", getImage(id));
            // $(".squares").each(function(i,img){
                // $(img).click(function(){
                //     processClick(id);
        //             $(img).attr("src","images/im"+i+".jpg");
        //         });
        //     });
        //     return $("#"+id).attr("src","images/im"+id+".jpg");
        // }
        // showImage();
        
        function hideImage(id){
            $("#"+id).attr("src","images/blank.jpg");
        }
        //     $(".squares").each(function(i,img){
        //         $(img).click(function(){
        //             processClick(id);
        //             $(img).attr("src","images/blank.jpg");
        //         });
        //     });
        //     return $("#"+id).attr("src","images/blank.jpg");
        // }
        // hideImage();
    
        var clickNumber = 1;
        var imageID;
        function processClick(id){
            if (clickNumber == 1){
                showImage();
                imageID = $("#"+id);
                clickNumber = 2;
            }
            else{
                if (id !== imageID){
                    showImage();
                    console.log("no match!")
                    setTimeout( hideImage(), 1000);
                clickNumber = 1;
            }
                
            }    
        }
        </script>